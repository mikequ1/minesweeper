//imports
import javax.swing.*;
import java.awt.*;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
//====================================================================================================================================================

//classes
public class MinesweeperGUI extends JFrame {
    //field variables
    private static GraphicsConfiguration gc;
    private JButton buttons[];
    private Space spaces[];
<<<<<<< Updated upstream
    private Toolkit toolkit;
    private MediaTracker tracker;
=======
<<<<<<< HEAD
    private Toolkit toolkit = Toolkit.getDefaultToolkit();
    private MediaTracker tracker = new MediaTracker(this);
>>>>>>> Stashed changes
    JFrame frame = new JFrame(gc);
    private GameLogic game;
<<<<<<< Updated upstream
=======
    Minesweeper newgame;
    Image image = toolkit.getImage("bombflagged.gif");
    Color brown = new Color(150,75,0);
    Color navyblue = new Color(0,0,140);
    Color cyan = new Color(0,128,128);
    Color green = new Color(0,100,0);
=======
    private Toolkit toolkit;
    private MediaTracker tracker;
    JFrame frame = new JFrame(gc);
    private GameLogic game;
>>>>>>> b0b31aa243dcc4b1cb6dc4f34fa27c5706537e04
>>>>>>> Stashed changes

    public MinesweeperGUI(Space spaces[], GameLogic game) {
        this.spaces = spaces;
        this.game = game;
<<<<<<< Updated upstream

    private JLabel labels[];
    private Toolkit toolkit;
    private MediaTracker tracker;
    //====================================================================================================================================================

    //constructors
    MinesweeperGUI(Space spaces[]) {
        JFrame frame = new JFrame(gc);
        toolkit = Toolkit.getDefaultToolkit();
        tracker = new MediaTracker(this);
        Image image = toolkit.getImage("bombflagged.gif");
=======
<<<<<<< HEAD
>>>>>>> Stashed changes
        tracker.addImage(image, 0);


        buttons = new JButton[GameLogic.getWidth() * GameLogic.getHeight()];

<<<<<<< Updated upstream
=======
        labels = new JLabel[Minesweeper.getWidth() * Minesweeper.getHeight()];
>>>>>>> parent of d1546ea (initial clear + open)
        Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
        for (int k=0; k<Minesweeper.getWidth() * Minesweeper.getHeight(); k++) {
            labels[k] = new JLabel(spaces[k].toString());
            labels[k].setPreferredSize(new Dimension(10,10));
            frame.add(labels[k]);
            labels[k].setBorder(border);

<<<<<<< HEAD
        for (int k=0; k<GameLogic.getWidth() * GameLogic.getHeight(); k++) {
=======
        for (int k=0; k<game.getWidth() * game.getHeight(); k++) {
=======

        toolkit = Toolkit.getDefaultToolkit();
        tracker = new MediaTracker(this);
        Image image = toolkit.getImage("bombflagged.gif");
        tracker.addImage(image, 0);

        buttons = new JButton[GameLogic.getWidth() * GameLogic.getHeight()];

        Border border = BorderFactory.createLineBorder(Color.BLACK, 1);

        for (int k=0; k<GameLogic.getWidth() * GameLogic.getHeight(); k++) {
>>>>>>> b0b31aa243dcc4b1cb6dc4f34fa27c5706537e04
>>>>>>> Stashed changes
            buttons[k] = new JButton();
            buttons[k].setPreferredSize(new Dimension(10,10));
            frame.add(buttons[k]);
            buttons[k].setBorder(border);
            // Set the label's font size to the newly determined size.
            buttons[k].setFont(new Font("Sans-Serif", Font.PLAIN, 25));
            buttons[k].setHorizontalAlignment(SwingConstants.CENTER);
            //buttons[k].setMnemonic(KeyEvent.VK_E);
            buttons[k].setActionCommand(spaces[k].getSpaceIDString());
            buttons[k].addActionListener(this);
            buttons[k].setBackground(Color.GRAY);
<<<<<<< Updated upstream
=======
<<<<<<< HEAD
            //buttons[k].addMouseListener(new MouseAdapter());
>>>>>>> Stashed changes
            buttons[k].setOpaque(true);
        }
        frame.setLayout(new GridLayout(GameLogic.getHeight(),GameLogic.getWidth()));
        frame.setTitle("Minesweeper");
        frame.setIconImage(image);
        frame.setVisible(true);
<<<<<<< Updated upstream
        frame.setSize(40 * GameLogic.getWidth(), 40 * GameLogic.getHeight());
=======
            // Set the label's font size to the newly determined size.
            labels[k].setFont(new Font("Sans-Serif", Font.PLAIN, 25));
            labels[k].setHorizontalAlignment(SwingConstants.CENTER);
        }
        frame.setLayout(new GridLayout(Minesweeper.getHeight(),Minesweeper.getWidth()));
        frame.setTitle("Minesweeper");
        frame.setIconImage(image);
        frame.setVisible(true);
        frame.setSize(40 * Minesweeper.getWidth(), 40 * Minesweeper.getHeight());
>>>>>>> parent of d1546ea (initial clear + open)
=======
        frame.setSize(40 * game.getWidth(), 40 * game.getHeight());
=======
            buttons[k].setOpaque(true);
        }
        frame.setLayout(new GridLayout(GameLogic.getHeight(),GameLogic.getWidth()));
        frame.setTitle("Minesweeper");
        frame.setIconImage(image);
        frame.setVisible(true);
        frame.setSize(40 * GameLogic.getWidth(), 40 * GameLogic.getHeight());
>>>>>>> b0b31aa243dcc4b1cb6dc4f34fa27c5706537e04
>>>>>>> Stashed changes
        frame.setLocation(200, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
    }
<<<<<<< HEAD

    public void open(JButton button, Space space) {
        int id = space.getSpaceID();
<<<<<<< Updated upstream
        int width = GameLogic.getWidth();
        int height = GameLogic.getHeight();
=======
<<<<<<< HEAD
        int width = game.getWidth();
        int height = game.getHeight();
>>>>>>> Stashed changes
        int total = width * height - 1;
        button.setBackground(Color.WHITE);
        space.uncover();
        
        if (space.isMine() && !space.isFlagged()) {
<<<<<<< Updated upstream
            System.exit(0);
=======
            win = new JFrame(gc);
            //button.setText("\uD83D\uDCA3");
            for (int i=0; i<buttons.length; i++) {
                if (spaces[i].isMine()) {
                    buttons[i].setText("*");
                    buttons[i].setBackground(Color.RED);
                }
            }
            win.setTitle("You lose!");
            tracker.addImage(image, 0);

            win.setDefaultLookAndFeelDecorated(true);        
            win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            win.setResizable(false);
            win.setIconImage(image);

            winpanel = new JPanel();
            BoxLayout boxlayout = new BoxLayout(winpanel, BoxLayout.Y_AXIS);
            winpanel.setLayout(boxlayout);
            winpanel.setBorder(new EmptyBorder(new Insets(10, 10, 10, 10)));

            JButton playagain = new JButton("Play again?");
            playagain.setMnemonic(KeyEvent.VK_E);
            playagain.setActionCommand("playagain");
            playagain.setToolTipText("Restarts the game");
            playagain.addActionListener(this);

            JButton back = new JButton("Change difficulty");
            back.setMnemonic(KeyEvent.VK_E);
            back.setActionCommand("return");
            back.setToolTipText("Returns to the difficulty screen");
            back.addActionListener(this);

            winpanel.add(playagain);
            winpanel.add(back);
            win.add(winpanel);
            win.pack();
            win.setVisible(true);
            game.hasWon = true;
=======
        int width = GameLogic.getWidth();
        int height = GameLogic.getHeight();
        int total = width * height - 1;
        button.setBackground(Color.WHITE);
        space.uncover();
        
        if (space.isMine() && !space.isFlagged()) {
            System.exit(0);
>>>>>>> b0b31aa243dcc4b1cb6dc4f34fa27c5706537e04
>>>>>>> Stashed changes
        }
        else if (space.isMine() && space.isFlagged()) {

        }
        else if (!space.isMine()) {
            if (space.getAdjacentMines() == 0)
                button.setText("");
<<<<<<< Updated upstream
            else
                button.setText(space.getAdjacentMinesString());
=======
<<<<<<< HEAD
            else {
                if (Integer.parseInt(space.getAdjacentMinesString()) == 1) {
                    button.setForeground(Color.BLUE);
                }
                else if (Integer.parseInt(space.getAdjacentMinesString()) == 2) {
                    button.setForeground(green);
                }
                else if (Integer.parseInt(space.getAdjacentMinesString()) == 3) {
                    button.setForeground(Color.RED);
                }
                else if (Integer.parseInt(space.getAdjacentMinesString()) == 4) {
                    button.setForeground(navyblue);
                }
                else if (Integer.parseInt(space.getAdjacentMinesString()) == 5) {
                    button.setForeground(brown);
                }
                else if (Integer.parseInt(space.getAdjacentMinesString()) == 6) {
                    button.setForeground(cyan);
                }
                else if (Integer.parseInt(space.getAdjacentMinesString()) == 7) {
                    button.setForeground(Color.BLACK);
                }
                else if (Integer.parseInt(space.getAdjacentMinesString()) == 8) {
                    button.setForeground(Color.GRAY);
                }
                button.setText(space.getAdjacentMinesString());
            }
=======
            else
                button.setText(space.getAdjacentMinesString());
>>>>>>> b0b31aa243dcc4b1cb6dc4f34fa27c5706537e04
>>>>>>> Stashed changes
            //North
            if (id - width >= 0 && spaces[id-width].isMine() == false && spaces[id-width].getCovered() == true && space.getAdjacentMines() == 0){
                open(buttons[id-width],spaces[id-width]);
            }
            //South  
            if (id + width <= total && spaces[id+width].isMine() == false && spaces[id+width].getCovered() == true && space.getAdjacentMines() == 0)
<<<<<<< Updated upstream
              {
=======
<<<<<<< HEAD
            {
=======
              {
>>>>>>> b0b31aa243dcc4b1cb6dc4f34fa27c5706537e04
>>>>>>> Stashed changes
                open(buttons[id+width],spaces[id+width]);
            }
            //West
            if (id - 1 >= 0 && space.getYPos() == spaces[id-1].getYPos() && spaces[id-1].isMine() == false
            && spaces[id-1].getCovered() == true && space.getAdjacentMines() == 0) {
                open(buttons[id-1],spaces[id-1]);
            }
            //East
            if (id + 1 <= total && space.getYPos() == spaces[id+1].getYPos() &&
            spaces[id+1].isMine() == false && spaces[id+1].getCovered() == true && space.getAdjacentMines() == 0) {
                open(buttons[id+1],spaces[id+1]);
            }
            //North-West
            if (id - width - 1 >= 0 && space.getYPos() - 1 == spaces[id-width-1].getYPos() &&
            spaces[id-width-1].isMine() == false && spaces[id-width-1].getCovered() == true &&
<<<<<<< Updated upstream
             space.getAdjacentMines() == 0) {
=======
<<<<<<< HEAD
            space.getAdjacentMines() == 0) {
=======
             space.getAdjacentMines() == 0) {
>>>>>>> b0b31aa243dcc4b1cb6dc4f34fa27c5706537e04
>>>>>>> Stashed changes
                open(buttons[id-width-1],spaces[id-width-1]);
            }
            //North-East
            if (id - width + 1 >= 0 && id - width + 1 <= width * height - 1 &&
            space.getYPos() - 1 == spaces[id-width+1].getYPos() && spaces[id-width+1].isMine() == false &&
            spaces[id-width+1].getCovered() == true &&  space.getAdjacentMines() == 0) {
                open(buttons[id-width+1],spaces[id-width+1]);
            }
            //South-West
            if (id + width - 1 >= 0 && id + width - 1 <= width * height - 1 &&
            space.getYPos() + 1 == spaces[id+width-1].getYPos() && spaces[id+width-1].isMine() == false
            && spaces[id+width-1].getCovered() == true &&  space.getAdjacentMines() == 0) {
                open(buttons[id+width-1],spaces[id+width-1]);
            }
            //South-East
            if (id + width + 1 <= width * height - 1 && space.getYPos() + 1 == spaces[id+width+1].getYPos() &&
            spaces[id+width+1].isMine() == false && spaces[id+width+1].getCovered() == true &&  space.getAdjacentMines() == 0) {
                open(buttons[id+width+1],spaces[id+width+1]);
            }
        }
        winGame();
<<<<<<< Updated upstream
        
    }
    
    
=======
<<<<<<< HEAD
    }

=======
        
    }
    
    
>>>>>>> b0b31aa243dcc4b1cb6dc4f34fa27c5706537e04
>>>>>>> Stashed changes
    public void winGame()
    {   
        int coveredCount = 0;
        for (int i = 0; i < spaces.length; i++)
        {
            if (spaces[i].getCovered() == true)
                coveredCount++;   
        }
<<<<<<< Updated upstream
        if (coveredCount == game.getMines())
=======
<<<<<<< HEAD
        if (coveredCount == game.getMines() && game.hasWon == false)
>>>>>>> Stashed changes
        {   
            frame.setVisible(false);
            frame.dispose();
            JFrame win = new JFrame(gc);
            System.out.println("you win");
        }
<<<<<<< Updated upstream
=======
=======
        if (coveredCount == game.getMines())
        {   
            frame.setVisible(false);
            frame.dispose();
            JFrame win = new JFrame(gc);
            System.out.println("you win");
        }
>>>>>>> Stashed changes
        System.out.println("run once");
        System.out.println(coveredCount);
        System.out.println(game.getMines());
    }
    
    
    public void actionPerformed(ActionEvent e) {
        int id = Integer.parseInt(e.getActionCommand());
        open(buttons[id],spaces[id]);
<<<<<<< Updated upstream
=======
>>>>>>> b0b31aa243dcc4b1cb6dc4f34fa27c5706537e04
>>>>>>> Stashed changes
    }
}
=======
    //====================================================================================================================================================
}
//====================================================================================================================================================
>>>>>>> parent of d1546ea (initial clear + open)
